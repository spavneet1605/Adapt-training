package springbootdemoproj.topics;

public class securityconfig {

}
