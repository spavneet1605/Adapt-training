package com.springsecurityassign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springsecurity9Application {

	public static void main(String[] args) {
		SpringApplication.run(Springsecurity9Application.class, args);
	}

}
