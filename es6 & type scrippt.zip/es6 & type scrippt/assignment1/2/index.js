var b = 10;
if (true) {
    var b_1 = 20;
    console.log(b_1);
}
console.log(b);
