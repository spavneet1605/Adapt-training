console.log("laptop model: acer, \n        your desk no:1536746, \n        your name:karthik ");
