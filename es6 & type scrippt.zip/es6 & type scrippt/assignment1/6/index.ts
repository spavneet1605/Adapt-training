    console.log(`laptop model: acer, 
        your desk no:1536746, 
        your name:karthik `)