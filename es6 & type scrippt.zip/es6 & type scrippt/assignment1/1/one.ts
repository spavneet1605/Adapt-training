 const a=10
    console.log(a)
   // a='a'
    console.log(` const a=10
               console.log(a)
                  a='a'     
        
        it will show message in cannot asign to a beacuse it is a constant`)