var a = 10;
console.log(a);
// a='a'
console.log(" const a=10\n               console.log(a)\n                  a='a'     \n        \n        it will show message in cannot asign to a beacuse it is a constant");
