package com.madhu.springREST7.API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class orderAPI {
	
	public static void main(String args[])
	{
		SpringApplication.run(orderAPI.class, args);
	}

}
