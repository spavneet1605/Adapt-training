
//same as Employee that I did in Question 5 
package com.madhu.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App 
{
public static void main(String args[])
{
	SpringApplication.run(App.class, args);
}
}
